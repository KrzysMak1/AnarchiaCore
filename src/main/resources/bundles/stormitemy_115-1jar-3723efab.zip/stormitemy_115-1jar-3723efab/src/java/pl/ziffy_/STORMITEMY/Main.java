/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Method
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Set
 *  java.util.function.Consumer
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabExecutor
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package pl.ziffy_.STORMITEMY;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import pl.ziffy_.STORMITEMY.core.ItemRegistry;
import pl.ziffy_.STORMITEMY.items.CA;
import pl.ziffy_.STORMITEMY.items.D;
import pl.ziffy_.STORMITEMY.items.HA;
import pl.ziffy_.STORMITEMY.items.JA;
import pl.ziffy_.STORMITEMY.items.R;
import pl.ziffy_.STORMITEMY.items.U;
import pl.ziffy_.STORMITEMY.items.c;
import pl.ziffy_.STORMITEMY.items.l;
import pl.ziffy_.STORMITEMY.items.n;
import pl.ziffy_.STORMITEMY.items.o;
import pl.ziffy_.STORMITEMY.regions.B;
import pl.ziffy_.STORMITEMY.ui.gui.E;
import pl.ziffy_.STORMITEMY.utils.update.A;
import pl.ziffy_.STORMITEMY.zaczarowania.C;

public class Main
extends JavaPlugin
implements TabExecutor,
Listener {
    private static final String C = "c3Rvcm1jb2Rl";
    private pl.ziffy_.STORMITEMY.core.B E;
    private final Map<String, Object> B = new HashMap();
    private String D;
    private volatile boolean F = false;
    private final Object A = new Object();

    public void onEnable() {
        this.D = this.getDescription().getVersion();
        Bukkit.getConsoleSender().sendMessage("\u00a78[\u00a72StormItemy\u00a78] \u00a77Plugin \u00a7fStormItemy \u00a77plugin \u00a7aw\u0142\u0105czony\u00a77! Wersja: \u00a7f" + this.D);
        this.E = new pl.ziffy_.STORMITEMY.core.B(this);
        this.E.K();
        this.B();
    }

    private void B() {
        A a2 = new A(this, 122499);
        a2.A(this.D, (Consumer<Boolean>)((Consumer)bl -> {
            String string;
            if (bl == null) {
                this.getLogger().warning("Nie uda\u0142o si\u0119 sprawdzi\u0107 aktualizacji.");
                return;
            }
            boolean bl2 = this.D.toUpperCase().endsWith("T");
            String string3 = string = bl2 ? " \u00a78(\u00a7cWERSJA TESTOWA\u00a78)" : "";
            if (!bl.booleanValue()) {
                Bukkit.getConsoleSender().sendMessage("\u00a78[\u00a72StormItemy\u00a78] \u00a77Plugin jest aktualny (wersja \u00a7f" + this.D + string + "\u00a77)");
            } else {
                a2.A((Consumer<String>)((Consumer)string2 -> {
                    if (string2 != null) {
                        Bukkit.getConsoleSender().sendMessage("\u00a78[\u00a72StormItemy\u00a78] \u00a77Znaleziono now\u0105 wersj\u0119: \u00a7f" + string2 + " \u00a77(aktualna: \u00a7f" + this.D + string + "\u00a77)");
                        Bukkit.getConsoleSender().sendMessage("\u00a78[\u00a72StormItemy\u00a78] \u00a77Pobierz aktualizacj\u0119 ze strony: \u00a7fhttps://www.spigotmc.org/resources/122499/");
                    }
                }));
            }
        }));
    }

    public Object getItem(String string) {
        return this.B.get((Object)string);
    }

    private void A(String string) {
        Bukkit.getConsoleSender().sendMessage("\u00a78[\u00a72StormItemy\u00a78] \u00a77" + string);
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    private void A() {
        Object object = this.A;
        synchronized (object) {
            this.F = true;
            this.A.notifyAll();
        }
    }

    public boolean areItemsInitialized() {
        return this.F;
    }

    public void setItemsInitialized(boolean bl) {
        this.F = bl;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent playerJoinEvent) {
        D d2;
        Player player = playerJoinEvent.getPlayer();
        Object object = this.getItem("plecakdrakuli");
        if (object instanceof D) {
            d2 = (D)object;
            Bukkit.getScheduler().runTaskLater((Plugin)this, () -> d2.restoreBackpackOnRespawn(player), 1L);
        }
        if (this.getConfig().getBoolean("updates.check-updates", true)) {
            Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
                int n2 = 122499;
                A a2 = new A(this, 122499);
                a2.A(this.D, (Consumer<Boolean>)((Consumer)bl -> {
                    if (bl != null && bl.booleanValue()) {
                        Bukkit.getScheduler().runTask((Plugin)this, () -> {
                            if (player.hasPermission("stormitemy.admin") || player.isOp()) {
                                a2.A((Consumer<String>)((Consumer)string -> {
                                    if (string != null) {
                                        Bukkit.getScheduler().runTask((Plugin)this, () -> player.sendMessage(pl.ziffy_.STORMITEMY.utils.color.A.C("\u00a78[\u00a7x\u00a7B\u00a73\u00a70\u00a70\u00a7F\u00a7F\ud83e\ude93\u00a78] \u00a77Dost\u0119pna jest nowa wersja pluginu: \u00a7x\u00a7D\u00a70\u00a76\u00a70\u00a7F\u00a7F" + string + " \u00a77(aktualna: \u00a7f" + this.D + "\u00a77). Pobierz aktualizacj\u0119 ze strony: \u00a7fhttps://www.spigotmc.org/resources/122499/")));
                                    }
                                }));
                            }
                        });
                    }
                }));
            }, 40L);
        }
        if (this.E != null && !this.E.Q) {
            Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
                if (player.hasPermission("stormitemy.admin") || player.isOp()) {
                    player.sendMessage(pl.ziffy_.STORMITEMY.utils.color.A.C("\u00a78[\u00a7x\u00a7F\u00a7F\u00a7C\u00a7F\u00a70\u00a70\u26a0\u00a78] \u00a77Nie wykryto pluginu \u00a7x\u00a7F\u00a7F\u00a7E\u00a70\u00a75\u00a7CWorldEdit\u00a77! Przedmioty \u00a7fTurboTrap \u00a77i \u00a7fTurboDomek \u00a77s\u0105 wy\u0142\u0105czone."));
                }
            }, 60L);
        }
        if (!((d2 = Bukkit.getPluginManager().getPlugin("Citizens")) != null && d2.isEnabled() || this.E != null && this.E.k)) {
            Bukkit.getScheduler().runTaskLater((Plugin)this, () -> {
                if (player.hasPermission("stormitemy.admin") || player.isOp()) {
                    player.sendMessage(pl.ziffy_.STORMITEMY.utils.color.A.C("\u00a78[\u00a7x\u00a7F\u00a7F\u00a7C\u00a7F\u00a70\u00a70\u26a0\u00a78] \u00a77Nie wykryto pluginu \u00a7x\u00a7F\u00a7F\u00a7E\u00a70\u00a75\u00a7CCitizens\u00a77! \u00a7fR\u00f3\u017cd\u017cka Iluzjonisty \u00a77wymaga Citizens do dzia\u0142ania."));
                }
            }, 80L);
        }
        if (this.E != null && this.E.R != null && this.E.R.D()) {
            this.E.R.A(player);
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent playerQuitEvent) {
        Player player = playerQuitEvent.getPlayer();
        Object object = this.getItem("plecakdrakuli");
        if (object instanceof D) {
            D d2 = (D)object;
            d2.clearPlayerData(player);
        }
    }

    /*
     * Exception decompiling
     */
    public boolean onCommand(CommandSender var1_1, Command var2_2, String var3_3, String[] var4_4) {
        /*
         * This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
         * 
         * ob.f0$e
         *     at ob.f0.e(SourceFile:35)
         *     at ob.f0.a(SourceFile:1)
         *     at ob.f0$d.a(SourceFile:68)
         *     at qb.n.i(SourceFile:13)
         *     at qb.e.i(SourceFile:9)
         *     at qb.l.i(SourceFile:14)
         *     at qb.n.i(SourceFile:3)
         *     at ob.f0.g(SourceFile:649)
         *     at ob.f0.d(SourceFile:37)
         *     at ib.f.d(SourceFile:235)
         *     at ib.f.e(SourceFile:7)
         *     at ib.f.c(SourceFile:95)
         *     at rc.f.n(SourceFile:11)
         *     at pc.i.m(SourceFile:5)
         *     at pc.d.K(SourceFile:92)
         *     at pc.d.g0(SourceFile:1)
         *     at fb.b.d(SourceFile:191)
         *     at fb.b.c(SourceFile:145)
         *     at fb.a.a(SourceFile:108)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.decompileWithCFR(SourceFile:76)
         *     at com.thesourceofcode.jadec.decompilers.JavaExtractionWorker.doWork(SourceFile:110)
         *     at com.thesourceofcode.jadec.decompilers.BaseDecompiler.withAttempt(SourceFile:3)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.d(SourceFile:53)
         *     at com.thesourceofcode.jadec.workers.DecompilerWorker.b(SourceFile:1)
         *     at e7.a.run(SourceFile:1)
         *     at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1154)
         *     at java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:652)
         *     at java.lang.Thread.run(Thread.java:1563)
         */
        throw new IllegalStateException("Decompilation failed");
    }

    public List<ItemStack> getAllItems() {
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList((Collection)this.B.keySet());
        arrayList2.sort((string, string2) -> {
            boolean bl = string.toLowerCase().contains((CharSequence)"anarchiczn");
            boolean bl2 = string2.toLowerCase().contains((CharSequence)"anarchiczn");
            if (bl && !bl2) {
                return 1;
            }
            if (!bl && bl2) {
                return -1;
            }
            return string.compareToIgnoreCase(string2);
        });
        for (String string3 : arrayList2) {
            try {
                Object object;
                ItemStack itemStack = ItemRegistry.getItemStack(string3);
                if (itemStack == null && (object = this.B.get((Object)string3)) != null) {
                    try {
                        Method method = object.getClass().getMethod("getItem", new Class[0]);
                        itemStack = (ItemStack)method.invoke(object, new Object[0]);
                    }
                    catch (Exception exception) {
                        // empty catch block
                    }
                }
                if (itemStack == null) continue;
                arrayList.add((Object)itemStack);
            }
            catch (Exception exception) {}
        }
        return arrayList;
    }

    public List<String> onTabComplete(CommandSender commandSender, Command command, String string, String[] stringArray) {
        if (command.getName().equalsIgnoreCase("stormitemy")) {
            if (!commandSender.hasPermission("stormitemy.admin")) {
                return Collections.emptyList();
            }
            if (this.E != null && this.E.Z != null) {
                return this.E.Z.A(commandSender, command, string, stringArray);
            }
        }
        return Collections.emptyList();
    }

    public pl.ziffy_.STORMITEMY.messages.B getActionbarManager() {
        return this.E != null ? this.E.L : null;
    }

    public pl.ziffy_.STORMITEMY.config.C getConfigManager() {
        return this.E != null ? this.E.D : null;
    }

    public pl.ziffy_.STORMITEMY.regions.C getRegionManager() {
        return this.E != null ? this.E.h : null;
    }

    public boolean isPlayerInBlockedRegion(Location location) {
        return this.E != null && this.E.O != null && this.E.O.B(location);
    }

    public boolean isTargetBlockInProtectedRegion(Location location) {
        return this.E != null && this.E.O != null && this.E.O.A(location);
    }

    public boolean isPlayerInBlockedRegion(Player player) {
        return this.E != null && this.E.O != null && this.E.O.A(player);
    }

    public B getRegionChecker() {
        return this.E != null ? this.E.K : null;
    }

    public pl.ziffy_.STORMITEMY.books.A getEnchantedBooksManager() {
        return this.E != null ? this.E.S : null;
    }

    public void onDisable() {
        if (this.E != null) {
            this.E.G();
        }
        pl.ziffy_.STORMITEMY.npc.A.A();
        if (this.E != null && this.E.R != null) {
            this.E.R.F();
        }
        if (this.E != null && this.E.L != null) {
            this.E.L.disable();
        }
        this.C();
        if (this.E != null && this.E.h != null) {
            this.E.h.D();
        }
        Bukkit.getScheduler().cancelTasks((Plugin)this);
        HandlerList.unregisterAll((Plugin)this);
        Bukkit.getConsoleSender().sendMessage("\u00a78\u00a7l[\u00a74StormItemy\u00a78\u00a7l] \u00a77Plugin \u00a7fStormItemy \u00a77plugin \u00a7cwy\u0142\u0105czony\u00a77!");
    }

    private void C() {
        try {
            Object object;
            Object object2;
            Object object3;
            Object object4;
            Object object5;
            Object object6;
            Object object7 = this.getItem("arcusmagnus");
            if (object7 != null && object7 instanceof pl.ziffy_.STORMITEMY.items.A) {
                ((pl.ziffy_.STORMITEMY.items.A)object7).cleanup();
            }
            if ((object6 = this.getItem("przeterminowanytrunek")) != null) {
                try {
                    object5 = object6.getClass().getMethod("onDisable", new Class[0]);
                    object5.invoke(object6, new Object[0]);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if ((object5 = this.getItem("wyrzutniahydroklatki")) != null) {
                try {
                    object4 = object5.getClass().getMethod("cleanupAllCages", new Class[0]);
                    object4.invoke(object5, new Object[0]);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if ((object4 = this.getItem("sakiewkadropu")) != null) {
                try {
                    object3 = object4.getClass().getMethod("closeDatabase", new Class[0]);
                    object3.invoke(object4, new Object[0]);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if ((object3 = this.getItem("balonikzhelem")) != null) {
                try {
                    object2 = object3.getClass().getMethod("cleanup", new Class[0]);
                    object2.invoke(object3, new Object[0]);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if ((object2 = this.getItem("blokwidmo")) != null) {
                try {
                    object = object2.getClass().getMethod("cleanup", new Class[0]);
                    object.invoke(object2, new Object[0]);
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            if ((object = this.getItem("cudownalatarnia")) != null) {
                try {
                    Method method = object.getClass().getMethod("cleanup", new Class[0]);
                    method.invoke(object, new Object[0]);
                }
                catch (Exception exception) {}
            }
        }
        catch (Exception exception) {
            this.getLogger().warning("B\u0142\u0105d podczas czyszczenia przedmiot\u00f3w: " + exception.getMessage());
        }
    }

    public pl.ziffy_.STORMITEMY.ui.menu.A getMenuManager() {
        return this.E != null ? this.E.T : null;
    }

    public C getZaczarowaniaManager() {
        return this.E != null ? this.E.l : null;
    }

    public pl.ziffy_.STORMITEMY.zaczarowania.B getLuckyEventManager() {
        return this.E != null ? this.E.R : null;
    }

    public pl.ziffy_.STORMITEMY.core.B getInitializer() {
        return this.E;
    }

    public pl.ziffy_.STORMITEMY.commands.B getPanelCommand() {
        return this.E != null ? this.E.H : null;
    }

    public boolean isWorldGuardPresent() {
        return this.E != null && this.E.a;
    }

    public pl.ziffy_.STORMITEMY.commands.D getBooksCommand() {
        return this.E != null ? this.E.E : null;
    }

    public E getCustomItemsManager() {
        return this.E != null ? this.E.Y : null;
    }

    public pl.ziffy_.STORMITEMY.texturepack.B getTexturePackManager() {
        return this.E != null ? this.E.g : null;
    }

    public Map<String, Object> getItems() {
        return this.B;
    }

    public Object getInitializationLock() {
        return this.A;
    }

    public boolean isWorldEditPresent() {
        return this.E != null && this.E.Q;
    }

    public boolean isCitizensPresent() {
        return this.E != null && this.E.k;
    }

    public boolean isItemDisabled(String string) {
        try {
            Set set;
            String string2;
            File file = new File(this.getDataFolder(), "items");
            if (!file.exists()) {
                return false;
            }
            File file2 = new File(file, string + ".yml");
            if (!file2.exists()) {
                string2 = string.replace((CharSequence)"_", (CharSequence)"");
                file2 = new File(file, string2 + ".yml");
            }
            if (!file2.exists()) {
                string2 = string.replace((CharSequence)"_", (CharSequence)"").toLowerCase();
                set = file.listFiles();
                if (set != null) {
                    for (Set set2 : set) {
                        if (!set2.getName().endsWith(".yml")) continue;
                        String string3 = set2.getName().replace((CharSequence)".yml", (CharSequence)"").toLowerCase();
                        if (string3.equals((Object)string2) || string3.replace((CharSequence)"_", (CharSequence)"").equals((Object)string2)) {
                            file2 = set2;
                            break;
                        }
                        try {
                            String string4;
                            String string5;
                            YamlConfiguration exception = YamlConfiguration.loadConfiguration((File)set2);
                            Set set3 = exception.getKeys(false);
                            if (set3.isEmpty() || !(string5 = (string4 = (String)set3.iterator().next()).replace((CharSequence)"_", (CharSequence)"").toLowerCase()).equals((Object)string2)) continue;
                            file2 = set2;
                            break;
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                    }
                }
            }
            if (!file2.exists()) {
                return false;
            }
            string2 = YamlConfiguration.loadConfiguration((File)file2);
            set = string2.getKeys(false);
            if (set.isEmpty()) {
                return false;
            }
            String string6 = (String)set.iterator().next();
            return string2.getBoolean(string6 + ".disabled", false);
        }
        catch (Exception exception) {
            this.getLogger().warning("[ItemEditor] B\u0142\u0105d przy sprawdzaniu stanu przedmiotu: " + exception.getMessage());
            return false;
        }
    }

    public c getSmoczyMiecz() {
        Object object = this.getItem("smoczymiecz");
        return object instanceof c ? (c)object : null;
    }

    public HA getBombardaMaxima() {
        Object object = this.getItem("bombardamaxima");
        return object instanceof HA ? (HA)object : null;
    }

    public n getBoskiTopor() {
        Object object = this.getItem("boskitopor");
        return object instanceof n ? (n)object : null;
    }

    public l getSniezka() {
        Object object = this.getItem("sniezka");
        return object instanceof l ? (l)object : null;
    }

    public U getSplesnialaKanapka() {
        Object object = this.getItem("splesnialakanapka");
        return object instanceof U ? (U)object : null;
    }

    public CA getTurboTrap() {
        Object object = this.getItem("turbotrap");
        return object instanceof CA ? (CA)object : null;
    }

    public JA getTurboDomek() {
        Object object = this.getItem("turbodomek");
        return object instanceof JA ? (JA)object : null;
    }

    public o getWedkaSurferka() {
        Object object = this.getItem("wedkasurferka");
        return object instanceof o ? (o)object : null;
    }

    public R getWedkaNielota() {
        Object object = this.getItem("wedkanielota");
        return object instanceof R ? (R)object : null;
    }

    public boolean isItemDisabledByKey(String string) {
        return this.isItemDisabled(string);
    }
}

