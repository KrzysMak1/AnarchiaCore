/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.Override
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  org.bukkit.Sound
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 */
package pl.ziffy_.STORMITEMY.books.enchantments;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import pl.ziffy_.STORMITEMY.Main;
import pl.ziffy_.STORMITEMY.books.D;

public class A
extends D {
    public A(Main main) {
        super(main, "Otrucie przeciwnika 1", "zatrucie", (List<String>)Arrays.asList((Object[])new String[]{"sword"}), 0.1, 20, (List<String>)Arrays.asList((Object[])new String[]{"&7Otrucie przeciwnika I", "&7", "&2&lZakl\u0119cie specjalne!", "&7Mo\u017ce zosta\u0107 na\u0142o\u017cony na &amiecz&7!", "&7Masz szans\u0119, \u017ce gracz kt\u00f3rego uderzysz", "&7otrzyma efekt trucizny I.", "&7"}));
    }

    @Override
    protected List<Map<String, Object>> getDefaultEffects() {
        ArrayList arrayList = new ArrayList();
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"type", (Object)"POISON");
        hashMap.put((Object)"duration", (Object)5);
        hashMap.put((Object)"amplifier", (Object)0);
        hashMap.put((Object)"particles", (Object)true);
        hashMap.put((Object)"ambient", (Object)false);
        hashMap.put((Object)"icon", (Object)true);
        arrayList.add((Object)hashMap);
        return arrayList;
    }

    @Override
    protected Map<String, Object> getDefaultSoundConfig() {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"enabled", (Object)true);
        hashMap.put((Object)"sound", (Object)"entity.witch.throw");
        hashMap.put((Object)"volume", (Object)1.0);
        hashMap.put((Object)"pitch", (Object)1.0);
        return hashMap;
    }

    @Override
    public void applyEffectToItem(ItemStack itemStack) {
        super.applyEffectToItem(itemStack);
    }

    @Override
    public void handleEffect(ItemStack itemStack, Object ... objectArray) {
        Object object;
        String string;
        Object object22;
        if (objectArray.length < 2) {
            return;
        }
        if (!(objectArray[0] instanceof Player) || !(objectArray[1] instanceof Entity)) {
            return;
        }
        Player player = (Player)objectArray[0];
        Entity entity = (Entity)objectArray[1];
        if (!(entity instanceof LivingEntity)) {
            return;
        }
        LivingEntity livingEntity = (LivingEntity)entity;
        List<Map<?, ?>> list = this.getEffects();
        for (Object object22 : list) {
            string = String.valueOf((Object)object22.get((Object)"type"));
            object = PotionEffectType.getByName((String)string);
            if (object == null) continue;
            int n2 = this.F((Map<?, ?>)object22, "duration", 5) * 20;
            int n3 = this.F((Map<?, ?>)object22, "amplifier", 0);
            boolean bl = this.F((Map<?, ?>)object22, "particles", true);
            boolean bl2 = this.F((Map<?, ?>)object22, "ambient", false);
            boolean bl3 = this.F((Map<?, ?>)object22, "icon", true);
            livingEntity.addPotionEffect(new PotionEffect(object, n2, n3, bl2, bl, bl3));
        }
        Iterator iterator = this.getSoundConfig();
        if (iterator != null && iterator.getBoolean("enabled", true)) {
            object22 = iterator.getString("sound", "entity.witch.throw");
            float f2 = (float)iterator.getDouble("volume", 1.0);
            float f3 = (float)iterator.getDouble("pitch", 1.0);
            try {
                Sound sound = Sound.valueOf((String)object22.toUpperCase().replace((CharSequence)".", (CharSequence)"_"));
                entity.getWorld().playSound(entity.getLocation(), sound, f2, f3);
            }
            catch (IllegalArgumentException illegalArgumentException) {
                entity.getWorld().playSound(entity.getLocation(), (String)object22, f2, f3);
            }
        }
        if (!(object22 = this.getAttackerChat().replace((CharSequence)"{TARGET}", (CharSequence)(entity instanceof Player ? ((Player)entity).getName() : "entity"))).isEmpty()) {
            player.sendMessage(pl.ziffy_.STORMITEMY.utils.color.A.C((String)object22));
        }
        string = this.getAttackerTitle();
        object = this.getAttackerSubtitle().replace((CharSequence)"{TARGET}", (CharSequence)(entity instanceof Player ? ((Player)entity).getName() : "entity"));
        if (!string.isEmpty() || !object.isEmpty()) {
            player.sendTitle(pl.ziffy_.STORMITEMY.utils.color.A.C(string), pl.ziffy_.STORMITEMY.utils.color.A.C((String)object), 10, 60, 20);
        }
        if (entity instanceof Player) {
            Player player2 = (Player)entity;
            String string2 = this.getTargetChat().replace((CharSequence)"{PLAYER}", (CharSequence)player.getName());
            if (!string2.isEmpty()) {
                player2.sendMessage(pl.ziffy_.STORMITEMY.utils.color.A.C(string2));
            }
            String string3 = this.getTargetTitle();
            String string4 = this.getTargetSubtitle().replace((CharSequence)"{PLAYER}", (CharSequence)player.getName());
            if (!string3.isEmpty() || !string4.isEmpty()) {
                player2.sendTitle(pl.ziffy_.STORMITEMY.utils.color.A.C(string3), pl.ziffy_.STORMITEMY.utils.color.A.C(string4), 10, 60, 20);
            }
        }
    }

    private int F(Map<?, ?> map, String string, int n2) {
        Object object = map.get((Object)string);
        if (object == null) {
            return n2;
        }
        if (object instanceof Number) {
            return ((Number)object).intValue();
        }
        if (object instanceof String) {
            try {
                return Integer.parseInt((String)((String)object));
            }
            catch (NumberFormatException numberFormatException) {
                return n2;
            }
        }
        return n2;
    }

    private boolean F(Map<?, ?> map, String string, boolean bl) {
        Object object = map.get((Object)string);
        if (object == null) {
            return bl;
        }
        if (object instanceof Boolean) {
            return (Boolean)object;
        }
        if (object instanceof String) {
            return Boolean.parseBoolean((String)((String)object));
        }
        return bl;
    }

    @Override
    protected FileConfiguration loadConfiguration() {
        FileConfiguration fileConfiguration = super.loadConfiguration();
        fileConfiguration.set("customModelData", (Object)1);
        try {
            this.saveCustomConfig((YamlConfiguration)fileConfiguration, this.configFile);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return fileConfiguration;
    }
}

