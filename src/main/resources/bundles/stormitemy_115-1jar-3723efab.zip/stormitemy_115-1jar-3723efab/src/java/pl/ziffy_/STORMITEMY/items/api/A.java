/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.inventory.ItemStack
 */
package pl.ziffy_.STORMITEMY.items.api;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

public interface A {
    public String B();

    public ItemStack D();

    public ConfigurationSection C();

    default public void A() {
    }
}

