/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.bukkit.event.player.PlayerInteractEvent
 */
package pl.ziffy_.STORMITEMY.items.api;

import org.bukkit.event.player.PlayerInteractEvent;
import pl.ziffy_.STORMITEMY.items.api.A;

public interface B
extends A {
    public void A(PlayerInteractEvent var1);
}

