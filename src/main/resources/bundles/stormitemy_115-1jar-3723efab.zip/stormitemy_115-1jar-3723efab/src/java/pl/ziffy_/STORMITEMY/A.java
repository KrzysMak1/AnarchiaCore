/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.AssertionError
 *  java.lang.Object
 *  java.lang.String
 */
package pl.ziffy_.STORMITEMY;

public final class A {
    public static final String b = "antycobweb";
    public static final String \u00c2 = "zmutowanycreeper";
    public static final String _ = "balonikzhelem";
    public static final String \u00a4 = "smoczymiecz";
    public static final String i = "bombardamaxima";
    public static final String G = "boskitopor";
    public static final String v = "sniezka";
    public static final String T = "splesnialakanapka";
    public static final String F = "turbotrap";
    public static final String K = "turbodomek";
    public static final String D = "wedkasurferka";
    public static final String U = "wedkanielota";
    public static final String g = "excalibur";
    public static final String E = "sakiewkadropu";
    public static final String s = "rozdzkailuzjonisty";
    public static final String S = "arcusmagnus";
    public static final String B = "blokwidmo";
    public static final String \u00b5 = "spawn";
    public static final String V = "pvp";
    public static final String \u00a5 = "FIREWORK_STAR";
    public static final String z = "CREEPER_SPAWN_EGG";
    public static final String O = "\u00a78[\u00a72StormItemy\u00a78] \u00a77";
    public static final String m = "\u00a78[\u00a74B\u0141\u0104D\u00a78] \u00a77";
    public static final String \u00c0 = "\u00a78[\u00a72\u2713\u00a78] \u00a7a";
    public static final String Q = "\u00a78[\u00a7x\u00a7B\u00a73\u00a70\u00a70\u00a7F\u00a7F\ud83e\ude93\u00a78] \u00a77";
    public static final String Z = "settings.language";
    public static final String I = "actionbar";
    public static final String d = "zaczarowania";
    public static final String A = "items";
    public static final String Y = "POL";
    public static final String \u00aa = "BLUE_DYE";
    public static final int j = 1;
    public static final int q = 20;
    public static final String e = "HIDE_ATTRIBUTES";
    public static final String C = "HIDE_ENCHANTS";
    public static final String n = "HIDE_UNBREAKABLE";
    public static final long \u00ba = 60000L;
    public static final int \u00a3 = 1000;
    public static final int y = 5000;
    public static final int L = 20;
    public static final String w = "\u00a7[0-9a-fk-or]";
    public static final String c = "&#([A-Fa-f0-9]{6})";
    public static final String x = "%([a-zA-Z0-9_]+)%";
    public static final String H = "stormitemy.admin";
    public static final String \u00c1 = "stormitemy.region";
    public static final String o = "stormitemy.actionbar";
    public static final String N = "stormitemy.give";
    public static final String f = "stormitemy";
    public static final String a = "si";
    public static final String u = "menuprzedmioty";
    public static final String W = "give";
    public static final String l = "reload";
    public static final String p = "version";
    public static final String J = "actionbar";
    public static final String M = "kills";
    public static final String h = "region";
    public static final String R = "zaczarowania";
    public static final String r = "panel";
    public static final String X = "customhit";
    public static final String t = "sakiewka";
    public static final String \u00a2 = "recover";
    public static final int k = 25765;
    public static final int P = 122499;

    private A() {
        throw new AssertionError((Object)"Nie mo\u017cna instancjonowa\u0107 Constants");
    }
}

