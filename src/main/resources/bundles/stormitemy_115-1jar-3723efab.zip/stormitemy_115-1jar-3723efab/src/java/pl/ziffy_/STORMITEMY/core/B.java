/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.function.Supplier
 *  org.bukkit.Bukkit
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.event.Listener
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package pl.ziffy_.STORMITEMY.core;

import java.util.function.Supplier;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import pl.ziffy_.STORMITEMY.Main;
import pl.ziffy_.STORMITEMY.bstats.bukkit.Metrics;
import pl.ziffy_.STORMITEMY.commands.G;
import pl.ziffy_.STORMITEMY.core.C;
import pl.ziffy_.STORMITEMY.core.ItemRegistry;
import pl.ziffy_.STORMITEMY.listeners.F;
import pl.ziffy_.STORMITEMY.regions.A;
import pl.ziffy_.STORMITEMY.ui.gui.E;
import pl.ziffy_.STORMITEMY.zaczarowania.D;

public class B {
    private final Main j;
    private final String N;
    public pl.ziffy_.STORMITEMY.config.C D;
    public pl.ziffy_.STORMITEMY.messages.B L;
    public pl.ziffy_.STORMITEMY.config.A B;
    public pl.ziffy_.STORMITEMY.ui.menu.A T;
    public pl.ziffy_.STORMITEMY.config.D M;
    public pl.ziffy_.STORMITEMY.regions.C h;
    public pl.ziffy_.STORMITEMY.regions.B K;
    public pl.ziffy_.STORMITEMY.items.E c;
    public A O;
    public pl.ziffy_.STORMITEMY.zaczarowania.C l;
    public D f;
    public pl.ziffy_.STORMITEMY.zaczarowania.A A;
    public pl.ziffy_.STORMITEMY.commands.C J;
    public pl.ziffy_.STORMITEMY.zaczarowania.B R;
    public pl.ziffy_.STORMITEMY.books.A S;
    public pl.ziffy_.STORMITEMY.books.C U;
    public pl.ziffy_.STORMITEMY.books.B F;
    public pl.ziffy_.STORMITEMY.commands.D E;
    public G G;
    public pl.ziffy_.STORMITEMY.commands.F I;
    public pl.ziffy_.STORMITEMY.listeners.B n;
    public pl.ziffy_.STORMITEMY.commands.B H;
    public pl.ziffy_.STORMITEMY.ui.gui.A _;
    public pl.ziffy_.STORMITEMY.listeners.D e;
    public F m;
    public pl.ziffy_.STORMITEMY.ui.gui.B i;
    public pl.ziffy_.STORMITEMY.listeners.C d;
    public pl.ziffy_.STORMITEMY.commands.A Z;
    public E Y;
    public pl.ziffy_.STORMITEMY.ui.gui.C V;
    public pl.ziffy_.STORMITEMY.ui.gui.D P;
    public pl.ziffy_.STORMITEMY.listeners.E X;
    public pl.ziffy_.STORMITEMY.listeners.A C;
    public pl.ziffy_.STORMITEMY.texturepack.B g;
    public pl.ziffy_.STORMITEMY.texturepack.A b;
    public pl.ziffy_.STORMITEMY.premium.A W;
    public boolean Q = false;
    public boolean a = false;
    public boolean k = false;

    public B(Main main) {
        this.j = main;
        this.N = main.getDescription().getVersion();
    }

    public void K() {
        try {
            this.J();
            this.N();
            this.A();
            this.I();
            this.F();
            this.L();
            this.O();
            this.H();
            this.E();
        }
        catch (Exception exception) {
            this.j.getLogger().severe("B\u0142\u0105d podczas inicjalizacji pluginu: " + exception.getMessage());
            exception.printStackTrace();
        }
    }

    private void J() {
        this.j.saveDefaultConfig();
        this.j.reloadConfig();
        this.B = new pl.ziffy_.STORMITEMY.config.A(this.j);
        this.B.G();
        this.B.A();
    }

    private void N() {
        if (this.j.getConfig().getBoolean("bstats.enabled", true)) {
            try {
                int n2 = 25765;
                new Metrics(this.j, n2);
                this.A("bStats w\u0142\u0105czony!");
            }
            catch (IllegalStateException illegalStateException) {
                this.j.getLogger().warning("Nie uda\u0142o si\u0119 zainicjalizowa\u0107 bStats: " + illegalStateException.getMessage());
            }
        } else {
            this.A("bStats wy\u0142\u0105czony!");
        }
    }

    private void A() {
        Plugin plugin = Bukkit.getPluginManager().getPlugin("WorldGuard");
        if (plugin == null || !plugin.isEnabled()) {
            this.A("Nie wykryto pluginu WorldGuard! U\u017cywanie wbudowanego systemu region\u00f3w.");
            this.a = false;
        } else {
            this.a = true;
            this.A("Wykryto plugin WorldGuard. Mo\u017cna u\u017cywa\u0107 obu system\u00f3w region\u00f3w.");
        }
        Plugin plugin2 = Bukkit.getPluginManager().getPlugin("WorldEdit");
        if (plugin2 == null || !plugin2.isEnabled()) {
            this.A("Nie wykryto pluginu WorldEdit! Przedmioty TurboTrap i TurboDomek b\u0119d\u0105 wy\u0142\u0105czone.");
            this.Q = false;
        } else {
            this.Q = true;
            this.A("Wykryto plugin WorldEdit. Przedmioty TurboTrap i TurboDomek s\u0105 dost\u0119pne.");
        }
        Plugin plugin3 = Bukkit.getPluginManager().getPlugin("Citizens");
        if (plugin3 == null || !plugin3.isEnabled()) {
            this.A("Nie wykryto pluginu Citizens! R\u00f3\u017cd\u017cka Iluzjonisty b\u0119dzie u\u017cywa\u0107 w\u0142asnego systemu NPC.");
            this.k = false;
        } else {
            this.k = true;
            this.A("Wykryto plugin Citizens! R\u00f3\u017cd\u017cka Iluzjonisty zosta\u0142a wy\u0142\u0105czona aby unikn\u0105\u0107 konflikt\u00f3w.");
        }
    }

    private void I() {
        this.D = new pl.ziffy_.STORMITEMY.config.C((Plugin)this.j);
        this.M = new pl.ziffy_.STORMITEMY.config.D((Plugin)this.j);
        this.L = new pl.ziffy_.STORMITEMY.messages.B((Plugin)this.j);
        this.T = new pl.ziffy_.STORMITEMY.ui.menu.A(this.j);
        this.h = new pl.ziffy_.STORMITEMY.regions.C(this.j);
        this.g = new pl.ziffy_.STORMITEMY.texturepack.B(this.j);
        this.b = new pl.ziffy_.STORMITEMY.texturepack.A(this.j, this.g);
        this.W = new pl.ziffy_.STORMITEMY.premium.A(this.j);
    }

    private void F() {
        this.m = new F(this.j);
        this.I = new pl.ziffy_.STORMITEMY.commands.F(this.j);
        this.n = new pl.ziffy_.STORMITEMY.listeners.B(this.j);
        this.Z = new pl.ziffy_.STORMITEMY.commands.A(this.j, this.L, null);
        this.l = new pl.ziffy_.STORMITEMY.zaczarowania.C(this.j);
        this.f = new D(this.j, this.l);
        this.l.A(this.f);
        this.A = new pl.ziffy_.STORMITEMY.zaczarowania.A(this.j, this.l);
        this.R = new pl.ziffy_.STORMITEMY.zaczarowania.B(this.j);
        this.J = new pl.ziffy_.STORMITEMY.commands.C(this.j, this.l);
        this.J.setEventManager(this.R);
        this.S = new pl.ziffy_.STORMITEMY.books.A(this.j);
        this.U = new pl.ziffy_.STORMITEMY.books.C(this.j, this.S);
        this.F = new pl.ziffy_.STORMITEMY.books.B(this.j, this.S);
        this.E = new pl.ziffy_.STORMITEMY.commands.D(this.j, this.S);
        this.C();
        this.Z = new pl.ziffy_.STORMITEMY.commands.A(this.j, this.L, this.S);
    }

    private void L() {
        this._ = new pl.ziffy_.STORMITEMY.ui.gui.A(this.j, this.h);
        this.H = new pl.ziffy_.STORMITEMY.commands.B(this.j, this._);
        this.i = new pl.ziffy_.STORMITEMY.ui.gui.B(this.j);
        this.d = new pl.ziffy_.STORMITEMY.listeners.C(this.j, this.i);
        this.i.A(this.d);
        this.e = new pl.ziffy_.STORMITEMY.listeners.D(this.j, this._, this.i);
        if (this.W != null && this.W.G()) {
            this.A("Premium aktywne - inicjalizacja kreatora w\u0142asnych przedmiot\u00f3w...");
            this.Y = new E(this.j);
            this.V = new pl.ziffy_.STORMITEMY.ui.gui.C(this.j, this.Y);
            this.P = new pl.ziffy_.STORMITEMY.ui.gui.D(this.j, this.Y);
            this.X = new pl.ziffy_.STORMITEMY.listeners.E(this.j, this.Y, this.V, this.P);
            this.C = new pl.ziffy_.STORMITEMY.listeners.A(this.j, this.Y);
            this.H.setCustomItemsListGUI(this.V);
        }
        this.c = new pl.ziffy_.STORMITEMY.items.E(this.j, this.h);
        this.G = new G(this.j, this.h, this.c);
        this.K = new pl.ziffy_.STORMITEMY.regions.B(this.j);
        this.O = new A(this.j, this.h, this.K);
    }

    private void O() {
        this.j.getCommand("stormitemy").setExecutor((CommandExecutor)this.j);
        this.j.getCommand("stormitemy").setTabCompleter((TabCompleter)this.j);
        pl.ziffy_.STORMITEMY.commands.E e2 = new pl.ziffy_.STORMITEMY.commands.E(this.j);
        this.j.getCommand("menuprzedmioty").setExecutor((CommandExecutor)e2);
    }

    private void H() {
        this.j.getServer().getPluginManager().registerEvents((Listener)this.j, (Plugin)this.j);
        this.j.getServer().getPluginManager().registerEvents((Listener)this.n, (Plugin)this.j);
        this.j.getServer().getPluginManager().registerEvents((Listener)this.e, (Plugin)this.j);
        this.j.getServer().getPluginManager().registerEvents((Listener)this.d, (Plugin)this.j);
        this.j.getServer().getPluginManager().registerEvents((Listener)new pl.ziffy_.STORMITEMY.ui.menu.B(this.j), (Plugin)this.j);
        if (this.X != null) {
            this.j.getServer().getPluginManager().registerEvents((Listener)this.X, (Plugin)this.j);
        }
        if (this.C != null) {
            this.j.getServer().getPluginManager().registerEvents((Listener)this.C, (Plugin)this.j);
        }
        if (this.b != null) {
            this.j.getServer().getPluginManager().registerEvents((Listener)this.b, (Plugin)this.j);
        }
    }

    private void E() {
        C c2 = new C(this.j, this.j.getItems(), this.j.getInitializationLock(), this.Q, this.k);
        c2.A();
    }

    private void A(String string) {
        Bukkit.getConsoleSender().sendMessage("\u00a78[\u00a72StormItemy\u00a78] \u00a77" + string);
    }

    public void G() {
        this.A("Zapisywanie wszystkich danych przed wy\u0142\u0105czeniem...");
        C c2 = new C(this.j, this.j.getItems(), this.j.getInitializationLock(), this.Q, this.k);
        c2.B();
        if (this.g != null) {
            this.g.G();
        }
        this.A("Wszystkie dane zosta\u0142y zapisane!");
    }

    public void D() {
        if (this.g != null) {
            this.g.H();
        }
    }

    public void M() {
        if (this.Y != null) {
            this.A("Kreator w\u0142asnych przedmiot\u00f3w ju\u017c zainicjalizowany.");
            return;
        }
        if (this.W == null || !this.W.G()) {
            this.A("Premium nieaktywne - nie mo\u017cna zainicjalizowa\u0107 kreatora.");
            return;
        }
        this.A("Inicjalizacja kreatora w\u0142asnych przedmiot\u00f3w po aktywacji premium...");
        this.Y = new E(this.j);
        this.V = new pl.ziffy_.STORMITEMY.ui.gui.C(this.j, this.Y);
        this.P = new pl.ziffy_.STORMITEMY.ui.gui.D(this.j, this.Y);
        this.X = new pl.ziffy_.STORMITEMY.listeners.E(this.j, this.Y, this.V, this.P);
        this.C = new pl.ziffy_.STORMITEMY.listeners.A(this.j, this.Y);
        if (this.H != null) {
            this.H.setCustomItemsListGUI(this.V);
        }
        this.j.getServer().getPluginManager().registerEvents((Listener)this.X, (Plugin)this.j);
        this.j.getServer().getPluginManager().registerEvents((Listener)this.C, (Plugin)this.j);
        this.A("Kreator w\u0142asnych przedmiot\u00f3w zainicjalizowany pomy\u015blnie!");
    }

    public boolean B() {
        return this.Y != null;
    }

    private void C() {
        if (this.S == null) {
            return;
        }
        for (pl.ziffy_.STORMITEMY.books.D d2 : this.S.C()) {
            String string = d2.getIdentifier();
            ItemRegistry.register(string, (Supplier<ItemStack>)((Supplier)d2::getBookItem), d2);
        }
    }
}

