package cc.dreamcode.antylogout.libs.eu.okaeri.persistence.document;

import cc.dreamcode.antylogout.libs.eu.okaeri.configs.configurer.Configurer;

public interface ConfigurerProvider
{
    Configurer get();
}
