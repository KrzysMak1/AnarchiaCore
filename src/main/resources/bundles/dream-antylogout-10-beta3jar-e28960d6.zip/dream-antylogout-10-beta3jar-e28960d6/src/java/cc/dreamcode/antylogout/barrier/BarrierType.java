package cc.dreamcode.antylogout.barrier;

public enum BarrierType
{
    KNOCKBACK, 
    BLOCK, 
    WALL, 
    IGNORE;
}
