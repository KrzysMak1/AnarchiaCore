package cc.dreamcode.antylogout.libs.cc.dreamcode.menu.bukkit.setup;

import org.bukkit.entity.HumanEntity;
import cc.dreamcode.antylogout.libs.cc.dreamcode.menu.bukkit.base.BukkitMenu;
import cc.dreamcode.antylogout.libs.cc.dreamcode.menu.setup.MenuPlayerSetup;

public interface BukkitMenuPlayerSetup extends MenuPlayerSetup<BukkitMenu, HumanEntity>
{
}
