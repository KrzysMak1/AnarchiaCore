package cc.dreamcode.antylogout.libs.eu.okaeri.persistence.mongo.filter;

import cc.dreamcode.antylogout.libs.eu.okaeri.persistence.filter.renderer.DefaultStringRenderer;

public class MongoStringRenderer extends DefaultStringRenderer
{
}
