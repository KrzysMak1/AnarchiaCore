package cc.dreamcode.antylogout.libs.cc.dreamcode.menu.bukkit.setup;

import org.bukkit.entity.HumanEntity;
import cc.dreamcode.antylogout.libs.cc.dreamcode.menu.bukkit.base.BukkitMenuPaginated;
import cc.dreamcode.antylogout.libs.cc.dreamcode.menu.setup.MenuPlayerSetup;

public interface BukkitMenuPaginatedPlayerSetup extends MenuPlayerSetup<BukkitMenuPaginated, HumanEntity>
{
}
