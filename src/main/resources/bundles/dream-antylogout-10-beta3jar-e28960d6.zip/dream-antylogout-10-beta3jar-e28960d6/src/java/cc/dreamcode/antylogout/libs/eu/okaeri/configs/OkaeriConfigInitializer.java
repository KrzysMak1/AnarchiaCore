package cc.dreamcode.antylogout.libs.eu.okaeri.configs;

public interface OkaeriConfigInitializer
{
    void apply(final OkaeriConfig config) throws Exception;
}
