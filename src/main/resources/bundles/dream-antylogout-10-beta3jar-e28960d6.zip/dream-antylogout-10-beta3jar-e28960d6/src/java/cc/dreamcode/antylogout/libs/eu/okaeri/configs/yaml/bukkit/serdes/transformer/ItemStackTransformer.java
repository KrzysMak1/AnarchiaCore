package cc.dreamcode.antylogout.libs.eu.okaeri.configs.yaml.bukkit.serdes.transformer;

import cc.dreamcode.antylogout.libs.eu.okaeri.configs.yaml.bukkit.serdes.transformer.experimental.StringBase64ItemStackTransformer;

@Deprecated
public class ItemStackTransformer extends StringBase64ItemStackTransformer
{
}
