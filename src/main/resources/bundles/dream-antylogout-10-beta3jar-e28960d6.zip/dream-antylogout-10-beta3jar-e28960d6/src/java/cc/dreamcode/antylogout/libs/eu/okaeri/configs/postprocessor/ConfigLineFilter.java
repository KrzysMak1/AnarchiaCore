package cc.dreamcode.antylogout.libs.eu.okaeri.configs.postprocessor;

public interface ConfigLineFilter
{
    boolean remove(final String line);
}
