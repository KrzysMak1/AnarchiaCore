package cc.dreamcode.antylogout.libs.eu.okaeri.placeholders;

public interface PlaceholderPack
{
    void register(final Placeholders placeholders);
}
