package cc.dreamcode.antylogout.libs.eu.okaeri.configs.serdes.standard;

import cc.dreamcode.antylogout.libs.eu.okaeri.configs.serdes.SerdesContext;
import lombok.NonNull;
import cc.dreamcode.antylogout.libs.eu.okaeri.configs.schema.GenericsPair;
import cc.dreamcode.antylogout.libs.eu.okaeri.configs.serdes.ObjectTransformer;

public class ObjectToStringTransformer extends ObjectTransformer<Object, String>
{
    @Override
    public GenericsPair<Object, String> getPair() {
        return this.genericsPair(Object.class, String.class);
    }
    
    @Override
    public String transform(@NonNull final Object data, @NonNull final SerdesContext serdesContext) {
        if (data == null) {
            throw new NullPointerException("data is marked non-null but is null");
        }
        if (serdesContext == null) {
            throw new NullPointerException("serdesContext is marked non-null but is null");
        }
        return data.toString();
    }
}
