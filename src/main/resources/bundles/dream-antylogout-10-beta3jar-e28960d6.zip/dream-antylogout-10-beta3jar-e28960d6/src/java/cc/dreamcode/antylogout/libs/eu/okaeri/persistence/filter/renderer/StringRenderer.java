package cc.dreamcode.antylogout.libs.eu.okaeri.persistence.filter.renderer;

public interface StringRenderer
{
    String render(final String text);
}
