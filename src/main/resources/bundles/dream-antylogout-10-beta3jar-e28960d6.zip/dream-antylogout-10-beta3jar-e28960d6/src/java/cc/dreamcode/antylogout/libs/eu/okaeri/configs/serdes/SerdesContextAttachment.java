package cc.dreamcode.antylogout.libs.eu.okaeri.configs.serdes;

public interface SerdesContextAttachment
{
}
