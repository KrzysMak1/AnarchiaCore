package cc.dreamcode.antylogout.libs.eu.okaeri.persistence.raw;

public enum PersistenceIndexMode
{
    NATIVE, 
    EMULATED, 
    NONE;
}
