package cc.dreamcode.antylogout.libs.eu.okaeri.placeholders.schema.resolver;

public interface SimplePlaceholderResolver<T>
{
    Object resolve(final T from);
}
