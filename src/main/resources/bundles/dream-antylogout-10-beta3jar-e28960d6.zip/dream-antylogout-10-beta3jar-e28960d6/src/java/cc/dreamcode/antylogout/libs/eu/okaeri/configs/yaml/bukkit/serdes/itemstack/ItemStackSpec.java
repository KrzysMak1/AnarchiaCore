package cc.dreamcode.antylogout.libs.eu.okaeri.configs.yaml.bukkit.serdes.itemstack;

import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Retention;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface ItemStackSpec {
    ItemStackFormat format() default ItemStackFormat.NATURAL;
}
