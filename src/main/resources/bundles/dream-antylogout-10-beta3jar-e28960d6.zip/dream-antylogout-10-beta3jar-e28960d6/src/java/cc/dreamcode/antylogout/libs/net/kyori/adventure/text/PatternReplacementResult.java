package cc.dreamcode.antylogout.libs.net.kyori.adventure.text;

public enum PatternReplacementResult
{
    REPLACE, 
    CONTINUE, 
    STOP;
}
