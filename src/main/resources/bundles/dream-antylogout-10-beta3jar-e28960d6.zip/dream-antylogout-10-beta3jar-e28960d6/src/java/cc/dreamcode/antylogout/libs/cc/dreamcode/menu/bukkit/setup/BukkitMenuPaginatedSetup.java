package cc.dreamcode.antylogout.libs.cc.dreamcode.menu.bukkit.setup;

import cc.dreamcode.antylogout.libs.cc.dreamcode.menu.bukkit.base.BukkitMenuPaginated;
import cc.dreamcode.antylogout.libs.cc.dreamcode.menu.setup.MenuSetup;

public interface BukkitMenuPaginatedSetup extends MenuSetup<BukkitMenuPaginated>
{
}
