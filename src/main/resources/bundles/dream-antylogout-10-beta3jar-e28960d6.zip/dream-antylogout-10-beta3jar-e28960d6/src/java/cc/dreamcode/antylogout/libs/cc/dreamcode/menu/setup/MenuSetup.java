package cc.dreamcode.antylogout.libs.cc.dreamcode.menu.setup;

public interface MenuSetup<M>
{
    M build();
}
