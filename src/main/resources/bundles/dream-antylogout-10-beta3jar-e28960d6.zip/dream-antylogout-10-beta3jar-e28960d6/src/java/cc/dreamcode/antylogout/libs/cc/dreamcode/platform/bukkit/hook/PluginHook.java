package cc.dreamcode.antylogout.libs.cc.dreamcode.platform.bukkit.hook;

public interface PluginHook
{
    default void onInit() {
    }
}
