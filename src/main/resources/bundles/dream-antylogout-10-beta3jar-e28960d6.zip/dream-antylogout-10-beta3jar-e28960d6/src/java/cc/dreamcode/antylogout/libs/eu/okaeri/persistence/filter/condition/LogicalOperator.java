package cc.dreamcode.antylogout.libs.eu.okaeri.persistence.filter.condition;

public enum LogicalOperator
{
    AND, 
    OR;
}
