package cc.dreamcode.antylogout.libs.eu.okaeri.placeholders.context;

public enum FailMode
{
    FAIL_SAFE, 
    FAIL_FAST;
}
