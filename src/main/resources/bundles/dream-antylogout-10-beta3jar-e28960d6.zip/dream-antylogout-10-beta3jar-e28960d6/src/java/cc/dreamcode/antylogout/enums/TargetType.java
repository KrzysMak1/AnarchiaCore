package cc.dreamcode.antylogout.enums;

public enum TargetType
{
    NONE, 
    PLAYER, 
    MONSTER, 
    BOTH;
}
