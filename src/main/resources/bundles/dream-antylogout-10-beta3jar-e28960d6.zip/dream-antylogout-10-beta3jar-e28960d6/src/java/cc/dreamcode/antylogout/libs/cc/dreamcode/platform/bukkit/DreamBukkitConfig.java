package cc.dreamcode.antylogout.libs.cc.dreamcode.platform.bukkit;

import cc.dreamcode.antylogout.libs.eu.okaeri.configs.serdes.OkaeriSerdesPack;

public interface DreamBukkitConfig
{
    OkaeriSerdesPack getConfigSerdesPack();
}
