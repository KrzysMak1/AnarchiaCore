package cc.dreamcode.antylogout.libs.eu.okaeri.configs.postprocessor;

public interface ConfigContextManipulator
{
    String convert(final String context);
}
