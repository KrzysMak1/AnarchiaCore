package cc.dreamcode.antylogout.libs.eu.okaeri.configs.yaml.bukkit.serdes.itemstack;

public enum ItemStackFailsafe
{
    NONE, 
    BASE64, 
    BUKKIT;
}
