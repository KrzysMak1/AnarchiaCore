package cc.dreamcode.antylogout.libs.net.kyori.adventure.text;

final class ComponentInternals
{
    static final String CHILDREN_PROPERTY = "children";
    
    private ComponentInternals() {
    }
}
