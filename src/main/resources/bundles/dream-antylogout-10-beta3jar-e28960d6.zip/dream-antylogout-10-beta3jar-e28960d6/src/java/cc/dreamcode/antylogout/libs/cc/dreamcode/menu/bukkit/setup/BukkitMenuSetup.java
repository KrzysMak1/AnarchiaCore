package cc.dreamcode.antylogout.libs.cc.dreamcode.menu.bukkit.setup;

import cc.dreamcode.antylogout.libs.cc.dreamcode.menu.bukkit.base.BukkitMenu;
import cc.dreamcode.antylogout.libs.cc.dreamcode.menu.setup.MenuSetup;

public interface BukkitMenuSetup extends MenuSetup<BukkitMenu>
{
}
