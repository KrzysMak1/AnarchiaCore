package cc.dreamcode.antylogout.libs.eu.okaeri.configs.serdes;

import lombok.NonNull;

public interface OkaeriSerdesPack
{
    void register(@NonNull final SerdesRegistry registry);
}
