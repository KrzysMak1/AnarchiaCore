package cc.dreamcode.antylogout.libs.eu.okaeri.configs.annotation;

public enum VariableMode
{
    RUNTIME, 
    WRITE;
}
