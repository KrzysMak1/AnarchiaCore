package cc.dreamcode.antylogout.libs.eu.okaeri.persistence.raw;

public enum PersistencePropertyMode
{
    NATIVE, 
    TOSTRING, 
    EQUALS;
}
