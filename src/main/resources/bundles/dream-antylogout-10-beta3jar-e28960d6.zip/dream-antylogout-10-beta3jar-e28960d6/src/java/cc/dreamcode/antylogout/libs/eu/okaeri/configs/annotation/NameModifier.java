package cc.dreamcode.antylogout.libs.eu.okaeri.configs.annotation;

public enum NameModifier
{
    NONE, 
    TO_UPPER_CASE, 
    TO_LOWER_CASE;
}
