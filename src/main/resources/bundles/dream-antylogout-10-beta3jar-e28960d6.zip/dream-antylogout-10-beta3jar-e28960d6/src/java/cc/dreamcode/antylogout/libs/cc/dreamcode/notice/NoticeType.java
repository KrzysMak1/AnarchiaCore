package cc.dreamcode.antylogout.libs.cc.dreamcode.notice;

import lombok.Generated;

public enum NoticeType
{
    DO_NOT_SEND, 
    CHAT, 
    ACTION_BAR, 
    SUBTITLE, 
    TITLE, 
    TITLE_SUBTITLE;
}
