package cc.dreamcode.antylogout.libs.eu.okaeri.persistence.filter.predicate;

public interface Predicate
{
    boolean check(final Object leftOperand);
}
