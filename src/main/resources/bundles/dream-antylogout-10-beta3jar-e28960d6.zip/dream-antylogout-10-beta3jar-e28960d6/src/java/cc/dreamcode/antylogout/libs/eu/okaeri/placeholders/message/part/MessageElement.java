package cc.dreamcode.antylogout.libs.eu.okaeri.placeholders.message.part;

public interface MessageElement
{
}
