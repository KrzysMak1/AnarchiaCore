package cc.dreamcode.antylogout.libs.eu.okaeri.configs.serdes.commons.duration;

public enum DurationFormat
{
    SIMPLIFIED, 
    ISO;
}
