package cc.dreamcode.antylogout.libs.eu.okaeri.configs.yaml.bukkit.serdes.itemstack;

public enum ItemStackFormat
{
    NATURAL, 
    COMPACT;
}
