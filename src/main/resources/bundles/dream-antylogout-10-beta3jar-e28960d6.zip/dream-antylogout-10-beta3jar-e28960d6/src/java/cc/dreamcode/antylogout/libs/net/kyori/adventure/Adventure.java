package cc.dreamcode.antylogout.libs.net.kyori.adventure;

public final class Adventure
{
    public static final String NAMESPACE = "adventure";
    
    private Adventure() {
    }
}
